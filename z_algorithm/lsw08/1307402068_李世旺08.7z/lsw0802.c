#include<stdio.h>
#include<stdlib.h>
#define N 24
#define DICE 6

int main()
{
int aa[N],ii,jj;
int count=0;

	for(jj=0;jj<N;jj++)aa[jj] = 1;
	
	while(aa[0] != DICE +1)
	{
		/* {	
		 for(jj=0;jj<N;jj++)
			{
			printf("%d ",aa[jj]);
			}
		printf("\n");
		} */
		
		aa[N-1]++;count++;
		for(ii=N-1;ii>=1;ii --)
		{
			if(aa[ii] == DICE +1)
			{
				aa[ii-1]++;				
				for(jj=ii;jj<N;jj++)
				{aa[jj]=aa[ii-1];}					
			}
		}		
	}
	printf("\n%d",count);
	return 0;
}