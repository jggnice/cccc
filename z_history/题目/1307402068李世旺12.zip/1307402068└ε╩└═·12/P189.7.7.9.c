#include"stdio.h"
int is_prime(int n)
{int p,i;
	for(i=2;i<n;i++)
{if(n%i==0)break;}
if(i==n)p=1;
else p=0;
return p;
}
int fun(int m,int b[])
{	int i,j=0;
	for(i=2;i<m;i++)
	{if(is_prime(i)==0){b[j]=i;j++;} }		
return j;}

main()
{int XX[100],i,y,m;
scanf("%d",&m);
y=fun(m,XX);
for(i=0;i<y;i++)printf("%d ",XX[i]);printf("����%d�� ",y);}